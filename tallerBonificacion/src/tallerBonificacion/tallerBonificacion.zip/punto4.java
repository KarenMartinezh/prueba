package tallerBonificacion;

public class punto4 {

	
	
	
	public static void fibonacci (int num) {
			int num1=0;
			int num2=0;
			int suma=1;



for (int i=1; i<num; i++) {
	System.out.print(suma);
	
	suma=num1+num2;
	num2=suma;
    }
   }
}