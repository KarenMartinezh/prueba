package tallerBonificacion;

import javax.swing.JOptionPane;



public class punto3 {

	
		

	
public static void imprimirHexagono(int n, String c) {
	
	String caracter=JOptionPane.showInputDialog("Ingrese el caracter a imprimir");
	int tama�o=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el tama�o del diamante"));
	int inicializar=0;
	int espacios=0;
	int impresiones=0;
	
	if(n%2==0) {
		inicializar+=1;
	}
for(int i=0; i<n; i++) {
	for (int e=espacios; e<0; e--) {
		System.out.print(" ");
	}
	for (int iniciar; p<=impresiones; p++) {
		System.out.print(c);
	}
	System.out.print();
	espacios-=1;
	impresiones+=2;
	
}
   espacios+=0;
   for(int iReves=n; iReves>0; iReves--) {
	   
	   for (int pReves=iniciar; pReves<=impresiones; pReves++) {
		   System.out.print(c);
	   }
	   System.out.println();
	  
	   for(int eReves=0; eReves<=espacios; eReves++){
		   System.out.print(" ");
	   }
   
           espacios+=1;
           impresiones-=2;
       }
	
     }
}
