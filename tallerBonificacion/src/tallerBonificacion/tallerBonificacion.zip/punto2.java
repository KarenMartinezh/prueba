package tallerBonificacion;

public class punto2 {

	


	
	
	
	
	public static String esVocal(char letra ) {
		
         String mensaje="";
          
          if(letra=='a'|| letra=='e'|| letra=='i'|| letra=='o'||letra=='u') {
        	 mensaje=("VOCAL");
          }
          else
          {
        	  mensaje=(" NO VOCAL");
          }
         
          
     if(letra!=' ') {
        		  mensaje=("El elemento ingresado no es valido");
        	  }
          
		return mensaje;
}
}
