package tallerBonificacion;

public class punto1 {

	public static void main(String[] args) {
	
		


		for (int i=0 ;i<5;i++) {
			
			int j;
			for ( j=0 ;j<i;j++) {
			System.out.print(i-j);
			j++;
}
	}
}


//Prueba de escrtitorio (ultima iteraccion)
	i=4
	j=0
	
	j(0)<i(4)
	4-0=4
	
	2<4
	4-2=2
Ultima iteraccion=2
//
}
